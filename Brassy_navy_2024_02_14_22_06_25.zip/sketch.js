// sketch.js
let video;
let currentEffect = 'NONE';

function setup() {
    createCanvas(640, 480);
    video = createCapture(VIDEO);
    video.size(640, 480);
    video.hide();
}

function draw() {
    switch (currentEffect) {
        case 'NONE':
            applyNone();
            break;
        case 'INVERT':
            applyInvert();
            break;
        case 'GRAYSCALE':
            applyGrayscale();
            break;
        case 'BLUR':
            applyBlur();
            break;
        case 'MOSAIC':
            applyMosaic(20);
            break;
        case 'BlackOnWhite':
            applyCustomOutline('BlackOnWhite');
            break;
        case 'WhiteOnBlack':
            applyCustomOutline('WhiteOnBlack');
            break;
        case 'BlackOnPink':
            applyCustomOutline('BlackOnPink');
            break;
        case 'PinkOnBlack':
            applyCustomOutline('PinkOnBlack');
            break;
        case 'YellowOnGreen':
            applyCustomOutline('YellowOnGreen');
            break;
        case 'GreenOnYellow':
            applyCustomOutline('GreenOnYellow');
            break;
        default:
            image(video, 0, 0, width, height); // 默认显示原视频，适用于未匹配任何特效的情况
            break;
    }
}

function setEffect(effect) {
    currentEffect = effect;
}

function applyNone() {
    image(video, 0, 0, width, height);
}

function applyInvert() {
    video.loadPixels();
    for (let i = 0; i < video.pixels.length; i += 4) {
        video.pixels[i] = 255 - video.pixels[i];
        video.pixels[i + 1] = 255 - video.pixels[i + 1];
        video.pixels[i + 2] = 255 - video.pixels[i + 2];
    }
    video.updatePixels();
    image(video, 0, 0);
}

function applyGrayscale() {
    video.loadPixels();
    for (let i = 0; i < video.pixels.length; i += 4) {
        let avg = (video.pixels[i] + video.pixels[i + 1] + video.pixels[i + 2]) / 3;
        video.pixels[i] = avg;
        video.pixels[i + 1] = avg;
        video.pixels[i + 2] = avg;
    }
    video.updatePixels();
    image(video, 0, 0);
}

function applyBlur() {
    image(video, 0, 0, width, height); // 首先绘制视频帧
    filter(BLUR, 10); // 应用模糊效果，数值越大，模糊程度越高
}





function applyMosaic(size) {
    video.loadPixels();
    for (let y = 0; y < video.height; y += size) {
        for (let x = 0; x < video.width; x += size) {
            let index = (x + y * video.width) * 4;
            let r = 0, g = 0, b = 0;
            for (let ny = 0; ny < size; ny++) {
                for (let nx = 0; nx < size; nx++) {
                    let ni = ((x + nx) + (y + ny) * video.width) * 4;
                    r += video.pixels[ni];
                    g += video.pixels[ni + 1];
                    b += video.pixels[ni + 2];
                }
            }
            r = r / (size * size);
            g = g / (size * size);
            b = b / (size * size);
            fill(r, g, b);
            noStroke();
            rect(x, y, size, size);
        }
    }
}

function applyCustomOutline(effect) {
    video.loadPixels();
    let resultImg = createImage(video.width, video.height);
    resultImg.loadPixels();

    for (let y = 0; y < video.height; y++) {
        for (let x = 0; x < video.width; x++) {
            let index = (x + y * video.width) * 4;
            let sum = 0;
            for (let ky = -1; ky <= 1; ky++) {
                for (let kx = -1; kx <= 1; kx++) {
                    let pos = ((x + kx) + (y + ky) * video.width) * 4;
                    let diff = abs(video.pixels[index] - video.pixels[pos]);
                    sum += diff;
                }
            }

            if (sum > 255 * 0.5) {
                switch (effect) {
                    case 'BlackOnWhite':
                        setPixelColor(resultImg, index, [0, 0, 0]);
                        break;
                    case 'WhiteOnBlack':
                        setPixelColor(resultImg, index, [255, 255, 255]);
                        break;
                    case 'BlackOnPink':
                        setPixelColor(resultImg, index, [0, 0, 0]);
                        break;
                    case 'PinkOnBlack':
                        setPixelColor(resultImg, index, [255, 192, 203]);
                        break;
                    case 'YellowOnGreen':
                        setPixelColor(resultImg, index, [255, 255, 0]);
                        break;
                    case 'GreenOnYellow':
                        setPixelColor(resultImg, index, [0, 128, 0]);
                        break;
                }
            } else {
                switch (effect) {
                    case 'BlackOnWhite':
                        setPixelColor(resultImg, index, [255, 255, 255]);
                        break;
                    case 'WhiteOnBlack':
                        setPixelColor(resultImg, index, [0, 0, 0]);
                        break;
                    case 'BlackOnPink':
                        setPixelColor(resultImg, index, [255, 192, 203]);
                        break;
                    case 'PinkOnBlack':
                        setPixelColor(resultImg, index, [0, 0, 0]);
                        break;
                    case 'YellowOnGreen':
                        setPixelColor(resultImg, index, [0, 128, 0]);
                        break;
                    case 'GreenOnYellow':
                        setPixelColor(resultImg, index, [255, 255, 0]);
                        break;
                }
            }
        }
    }

    resultImg.updatePixels();
    image(resultImg, 0, 0);
}

function setPixelColor(img, index, color) {
    img.pixels[index] = color[0]; // 设置红色通道
    img.pixels[index + 1] = color[1]; // 设置绿色通道
    img.pixels[index + 2] = color[2]; // 设置蓝色通道
    img.pixels[index + 3] = 255; // 设置Alpha通道为不透明
}
